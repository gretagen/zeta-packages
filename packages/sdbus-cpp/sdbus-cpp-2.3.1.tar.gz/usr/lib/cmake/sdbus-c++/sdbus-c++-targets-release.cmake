#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SDBusCpp::sdbus-c++" for configuration "Release"
set_property(TARGET SDBusCpp::sdbus-c++ APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SDBusCpp::sdbus-c++ PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libsdbus-c++.so.2.3.1"
  IMPORTED_SONAME_RELEASE "libsdbus-c++.so.2"
  )

list(APPEND _cmake_import_check_targets SDBusCpp::sdbus-c++ )
list(APPEND _cmake_import_check_files_for_SDBusCpp::sdbus-c++ "${_IMPORT_PREFIX}/lib/libsdbus-c++.so.2.3.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
