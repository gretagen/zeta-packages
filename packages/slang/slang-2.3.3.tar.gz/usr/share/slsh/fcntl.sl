import("fcntl");
provide("fcntl");
